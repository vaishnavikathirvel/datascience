# Python_Bus_Booking_System
A program built using GUI library in Python and MySQL driver which stores a database of bus schedules and generates a passenger ticket on successful booking.
